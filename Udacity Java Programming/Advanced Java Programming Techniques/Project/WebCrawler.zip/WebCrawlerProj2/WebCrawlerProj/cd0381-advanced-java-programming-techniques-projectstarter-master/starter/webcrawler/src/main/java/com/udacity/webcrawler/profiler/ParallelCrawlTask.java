package com.udacity.webcrawler.profiler;

import com.udacity.webcrawler.parser.PageParser;
import com.udacity.webcrawler.parser.PageParserFactory;

import java.time.Clock;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ConcurrentSkipListSet;
import java.util.concurrent.RecursiveTask;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.regex.Pattern;

public class ParallelCrawlTask extends RecursiveTask<Boolean> {

    private final String URL;
    private final Instant END;
    private final int maxDepth;
    private final ConcurrentMap<String,Integer> counts;
    private final ConcurrentSkipListSet<String> visitedURLS;
    private final Clock clock;
    private final PageParserFactory parserFactory;
    private final List<Pattern> ignoredURLS;

    private ParallelCrawlTask(Builder builder){


        this.URL = builder.URL;
        this.END = builder.END;
        this.maxDepth = builder.maxDepth;
        this.counts = builder.counts;
        this.visitedURLS = builder.visitedURLS;
        this.clock = builder.clock;
        this.parserFactory = builder.parserFactory;
        this.ignoredURLS = builder.ignoredURLS;
    }

    @Override
    protected Boolean compute() {
        if (maxDepth == 0 || clock.instant().isAfter(END)) {
            return false;
        }
        for (Pattern pattern : ignoredURLS) {
            if (pattern.matcher(URL).matches()) {
                return false;
            }
        }
        synchronized (visitedURLS) {
            if (visitedURLS.contains(URL)) {
                return false;
            }
            visitedURLS.add(URL);
        }

        PageParser.Result result = parserFactory.get(URL).parse();

       /** for(ConcurrentMap.Entry<String,Integer> e: result.getWordCounts().entrySet())
        {
            if (counts.containsKey(e.getKey())) {
                counts.put(e.getKey(), e.getValue() + counts.get(e.getKey()));
            } else {
                counts.put(e.getKey(), e.getValue());
            }
        } **/
        for (ConcurrentMap.Entry<String, Integer> e : result.getWordCounts().entrySet()) {
            counts.compute(e.getKey(), (key, oldValue) -> (oldValue == null) ? e.getValue() : e.getValue() + oldValue);
        }

        List<ParallelCrawlTask> subtasks = new ArrayList<>();
        for (String link : result.getLinks()) {

            subtasks.add(new ParallelCrawlTask.Builder().setDeadline(END)
                    .setClock(clock).setCounts(counts).setMaxDepth(maxDepth-1)
                    .setIgnoredUrls(ignoredURLS).setParserFactory(parserFactory)
                    .setVisitedUrls(visitedURLS).setUrl(link).build());
        }
        invokeAll(subtasks);
        return true;


    }


    public static final class Builder {
        private String URL;
        private Instant END;
        private int maxDepth;
        private ConcurrentMap<String, Integer> counts;
        private ConcurrentSkipListSet<String> visitedURLS;
        private Clock clock;
        private PageParserFactory parserFactory;
        private List<Pattern> ignoredURLS;

        public Builder(){}

        public Builder setUrl(String url) {
            this.URL = url;
            return this;
        }

        public Builder setDeadline(Instant deadline) {
            this.END = deadline;
            return this;
        }

        public Builder setMaxDepth(int maxDepth) {
            this.maxDepth = maxDepth;
            return this;
        }

        public Builder setCounts(ConcurrentMap<String, Integer> counts) {
            this.counts = counts;
            return this;
        }

        public Builder setVisitedUrls(ConcurrentSkipListSet<String> visitedUrls) {
            this.visitedURLS = visitedUrls;
            return this;
        }

        public Builder setClock(Clock clock) {
            this.clock = clock;
            return this;
        }

        public Builder setParserFactory(PageParserFactory parserFactory) {
            this.parserFactory = parserFactory;
            return this;
        }

        public Builder setIgnoredUrls(List<Pattern> ignoredUrls) {
            this.ignoredURLS = ignoredUrls;
            return this;
        }

        public ParallelCrawlTask build() {
            return new ParallelCrawlTask(this);
        }
    }

}
