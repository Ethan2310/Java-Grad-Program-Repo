package com.udacity.catpoint.security.service;

import com.udacity.catpoint.security.data.*;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import service.com.udacity.catpoint.image.service.ImageService;

import java.awt.image.BufferedImage;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.mockito.Mockito.*;


@ExtendWith(MockitoExtension.class)
public class SecurityServiceTest {

    @Mock
     ImageService imageService;
    @Mock
     SecurityRepository securityRepository;
    @Mock
     BufferedImage bufferedImage;

     private SecurityService securityService;

    private Sensor sensor;

    private Set<Sensor> sensors;

    private final String randomString = UUID.randomUUID().toString();




    private Sensor getSensor(){
        return new Sensor(randomString, SensorType.DOOR);
    }





    @BeforeEach
    public void setUp() {
     //   MockitoAnnotations.openMocks(this);
        securityService = new SecurityService(securityRepository, imageService);
        sensor = getSensor();

    }

    private Set<Sensor> getSensorTest(boolean active, int count){
        String randomString = UUID.randomUUID().toString();

        Set<Sensor> sensor = new HashSet<>();
        for (int i = 0; i <= count; i++){
            sensor.add(new Sensor(randomString, SensorType.DOOR));
        }
        sensor.forEach(it -> it.setActive(active));
        return sensor;
    }


    @Test
    @DisplayName("Test 1")
    public void setAlarmStatus_ifAlarmIsArmedAndSensorActivated_putSystemIntoPendingAlarm() {

        //arrange
        when(securityService.getArmingStatus()).thenReturn(ArmingStatus.ARMED_HOME);
        when(securityService.getAlarmStatus()).thenReturn(AlarmStatus.NO_ALARM);

        //act
        securityService.changeSensorActivationStatus(sensor, true);

        //assert
        ArgumentCaptor<AlarmStatus> cap = ArgumentCaptor.forClass(AlarmStatus.class);
        verify(securityRepository, atMostOnce()).setAlarmStatus(cap.capture());
        Assertions.assertEquals(cap.getValue(), AlarmStatus.PENDING_ALARM);
    }

    @ParameterizedTest
    @EnumSource(value = ArmingStatus.class, names = {"ARMED_AWAY","ARMED_HOME"})
    @DisplayName("Test 2")
    public void setAlarmStatus_ifAlarmArmedAndSensorActivatedAndAlarmPending_setAlarmStatusToAlarm(ArmingStatus armingStatus) {

        //arrange
        when(securityService.getArmingStatus()).thenReturn(armingStatus);
        when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.PENDING_ALARM);


        //act
        securityService.changeSensorActivationStatus(sensor, true);

        //verify
        verify(securityRepository, atMostOnce()).setAlarmStatus(AlarmStatus.ALARM);
    }

    @Test
    @DisplayName("Test 3")
    public void setAlarmStatus_ifPendingAlarmAndAllSensorsInactive_setNoAlarmState() {

        //arrange
        Set<Sensor> sensorSet = getSensorTest(false,4);
        Sensor first = sensorSet.iterator().next();
        first.setActive(true);
        when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.PENDING_ALARM);

        //act
        securityService.changeSensorActivationStatus(first, false);

        //assert
        verify(securityRepository, times(1)).setAlarmStatus(AlarmStatus.NO_ALARM);
    }

    @ParameterizedTest
    @ValueSource(booleans ={true,false})
    @DisplayName("Test 4")
    public void ifAlarmActive_changeInSensorStateShouldNotAffectAlarmState(boolean armState)
    {
        //arrange
        when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.ALARM);
       // sensorDoor.setActive(armState);

        //act
        securityService.changeSensorActivationStatus(sensor,armState);

        //verify
        verify(securityRepository,never()).setAlarmStatus(any());

    }


    @Test
    @DisplayName("Test 5")
    public void setAlarmStatus_ifSensorActivatedWhileActiveAndSystemPending_changeToAlarmState()
    {
        // arrange
        when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.PENDING_ALARM);


        //act
        securityService.changeSensorActivationStatus(sensor,true);

        //verify
        verify(securityRepository,atMostOnce()).setAlarmStatus(AlarmStatus.ALARM);

    }



    @ParameterizedTest
    @EnumSource(value = AlarmStatus.class, names = {"NO_ALARM", "PENDING_ALARM", "ALARM"})
    @DisplayName("Test 6")
    public void setAlarmStatus_ifSensorDeactivatedWhileInactive_noChangeToAlarmState(AlarmStatus alarmStatus)
    {
        //act
        securityService.changeSensorActivationStatus(sensor,false);
        verify(securityRepository,never()).setAlarmStatus(any());

    }

    @Test
    @DisplayName("Test 7")
    public void setAlarmStatus_ifImageServiceIdentifiesAnImageContainingACatWhileSystemIsArmedHome_putSystemIntoAlarmStatus()
    {
        //arrange
        when(imageService.imageContainsCat(any(),anyFloat())).thenReturn(true);
        when(securityService.getArmingStatus()).thenReturn(ArmingStatus.ARMED_HOME);


        //act
        securityService.processImage(mock(BufferedImage.class));

        //assert
        ArgumentCaptor<AlarmStatus> cap = ArgumentCaptor.forClass(AlarmStatus.class);
        verify(securityRepository, atMostOnce()).setAlarmStatus(cap.capture());
        assertEquals(cap.getValue(), AlarmStatus.ALARM);
    }


    @Test
    @DisplayName("Test 8")
    public void setAlarmStatus_ifImageServiceIdentifiesImageNotContainingACat_changeStatusToNoAlarmAsLongAsSensorsAreNotActive()
    {

        //arrange
        Set<Sensor> sensorSet = getSensorTest(false,2);
        when(securityRepository.getSensors()).thenReturn(sensorSet);
        when(imageService.imageContainsCat(any(),anyFloat())).thenReturn(false);


        //act
        securityService.processImage(mock(BufferedImage.class));

        //assert
        verify(securityRepository,atMostOnce()).setAlarmStatus(AlarmStatus.NO_ALARM);
    }

    @Test
    @DisplayName("Test 9")
    public void setAlarmStatus_ifSystemIsDisarmed_setStatusToNoAlarm()
    {
        //act
        securityService.setArmingStatus(ArmingStatus.DISARMED);

        //assert
        verify(securityRepository,atMostOnce()).setAlarmStatus(AlarmStatus.NO_ALARM);
    }

    @ParameterizedTest
    @EnumSource(value = ArmingStatus.class, names = {"ARMED_AWAY","ARMED_HOME"})
    @DisplayName("Test 10")
    public void changeSensorActivationStatus_ifSystemIsArmed_resetAllSensorsToInactive(ArmingStatus armingStatus) {
        // arrange
        Set<Sensor> testSensors = getSensorTest(true, 3);
        when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.PENDING_ALARM);
        when(securityRepository.getSensors()).thenReturn(testSensors);

        // act
        securityService.setArmingStatus(armingStatus);

        // assert
        securityRepository.getSensors().forEach(sensor -> assertEquals(false, sensor.getActive()));
    }

    @Test
    @DisplayName("Test 11")
    public void ifSystemIsArmedHomeWhileCameraShowsACat_setAlarmStatusToAlarm()
    {

      // arrange
        when(imageService.imageContainsCat(any(), anyFloat())).thenReturn(true);
        when(securityRepository.getArmingStatus()).thenReturn(ArmingStatus.ARMED_HOME);

       //act
        securityService.processImage(mock(BufferedImage.class));

        //assert
        ArgumentCaptor<AlarmStatus> captor = ArgumentCaptor.forClass(AlarmStatus.class);
        verify(securityRepository, atMostOnce()).setAlarmStatus(captor.capture());
        assertEquals(captor.getValue(), AlarmStatus.ALARM);

    }



}
